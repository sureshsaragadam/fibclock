package code.fibclock.stage11

import ColorViewModel
import androidx.compose.runtime.Composable
import com.google.common.collect.Sets

//var superSetList: List<Int> = listOf(0,1,2,3,5)

@Composable
fun HandlePowerSet(colorViewModel: ColorViewModel) {
    // define the set of fibonacci blocks
    val mySet = setOf(0, 1, 2, 3, 5)

    // using Sets library to get the powerSet
    val powerList = Sets.powerSet(mySet)
    // Convert the powerList to a list of lists
    val powerSetList = powerList.map { it.toList() }.toList()

    // Now you can use powerSetList in your Kotlin code
    println("---- Printing the size of the powerSet ----")
    println(powerSetList.size)

    println(powerSetList)
    println("---- Printing actual PowerSet Success! ----")

    println("---- Printing with set loop of PowerSet ----")
    for (set in powerSetList) {
        println(set)
    }
    println("---- Loop End ----")

    // mapping 0 to 1 in the modifiedPowerSetList
    val modifiedPowerSetList = powerSetList.map { innerList ->
        innerList.map { if (it == 0) 1 else it }
    }

    // create list of sums using the modifiedPowerSetList
    val sumList = modifiedPowerSetList.map { innerList ->
        innerList.sum()
    }

    println("---- Printing Modified PowerSet ----")
    println(modifiedPowerSetList)
    println("---- End of the Printing Modified PowerSet ----")
    println("----  Modified PowerSet Size Kotlin ----")
    println(modifiedPowerSetList.size)

    println("---- Printing sumlist ----")
    println(sumList)

    for (i in sumList.indices) {
        val sum = sumList[i]
        val set = powerSetList[i]
        println("Sum: $sum, Set: $set")
    }
    // the values of hours and minutes are updated in getmyTime
    // the getmyTime fun is scheduled to start from the fun startScheduling()
    // startScheduling() is called from MainActivity.kt

    println("<---- printing time to work with ")
    println(colorViewModel.hours.value)
    println(colorViewModel.minutes.value)
    println(colorViewModel.dayNightState.value)
    println("<---- End printing View Model TIME ")

    val hourscope = colorViewModel.hours.value
    val minutescope = colorViewModel.minutes.value / 5
    val hourlist = mutableListOf<List<Int>>()
    val minuteslist = mutableListOf<List<Int>>()

    println("<---- printing hourscope")
    for (i in sumList.indices) {
        if (sumList[i] == hourscope) {
            val sum = sumList[i]
            val set = powerSetList[i]
            // i need to add the value set to new list and then print it
            hourlist.add(set.toList())
            println("Sum: $sum, Set: $set")
        }
    }
    println("<---- printing hourlist")
    println(hourlist)

    println("<---- printing minutescope")
    for (i in sumList.indices) {
        if (sumList[i] == minutescope) {
            val sum = sumList[i]
            val set = powerSetList[i]
            minuteslist.add(set.toList())
            println("Sum: $sum, Set: $set")
        }
    }

    println("<---- printing minuteslist")
    println(minuteslist)
//    println(superSetList)

    val disjointPair = hourlist.mapIndexedNotNull { hourIndex, hourSet ->
        minuteslist.mapIndexedNotNull { minuteIndex, minuteSet ->
            if (hourSet.all { it !in minuteSet }) { // Check for disjoint sets
                Pair(hourIndex, minuteIndex) // Return indices of disjoint sets
            } else null
        }
    }.flatten().firstOrNull() // Flatten and get the first disjoint pair

    if (disjointPair != null) {
        val (hourIndex, minuteIndex) = disjointPair
        println("kotlin Disjoint pair found: ${hourlist[hourIndex]} and ${minuteslist[minuteIndex]}")
    } else {
        println("=====> NO DISJOINT PAIR FOUND <=====")
    }
    // Find disjoint pairs
    val disjointPairs = hourlist.flatMap { hourSet ->
        minuteslist.mapNotNull { minuteSet ->
            if (Sets.intersection(hourSet.toSet(), minuteSet.toSet()).isEmpty()) {
                Pair(hourSet, minuteSet)
            } else null
        }
    }
    // Print the disjoint pairs
    println("===== disjoint pairs ====")
    println(disjointPairs)
    println("===== end of disjoint pairs ====")

    // Find joint pairs
    val jointPairs = hourlist.flatMap { hourSet ->
        minuteslist.mapNotNull { minuteSet ->
            if (Sets.intersection(hourSet.toSet(), minuteSet.toSet()).isNotEmpty()) {
                Pair(hourSet, minuteSet)
            } else null
        }
    }

    // Print the joint pairs
    println("===== joint pairs ====")
    println(jointPairs)
    println("===== end of joint pairs ====")

    // Print the disjoint pairs
    println("===== Printing forEach disjoint pair ====")
    disjointPairs.forEach { pair ->
        println("Hour set: ${pair.first}, Minute set: ${pair.second}")
    }
    println("===== End of Printing forEach disjoint pair ====")


    // Print the joint pairs
    println("===== Printing forEach joint pair ====")
    jointPairs.forEach { pair ->
        println("Hour set: ${pair.first}, Minute set: ${pair.second}")
    }
    println("===== End of Printing forEach joint pair ====")

    // if disjoint pairs were found using sets return the best disjoint pair else return the best joint pairs
    if (disjointPairs.isNotEmpty())
    {
        println("**** RESULT **** Printing the best disjoint pair **** COLOR CODE ****")
        // Fetch the least disjoint pair (the pair with the smallest hour or minute set size)
        val leastDisjointPair = disjointPairs.minByOrNull { pair ->
            pair.first.size
        }
        // Safely print the least disjoint pair with null checks
        println("===== Printing least disjoint pair ====")
        println("Hour set: ${leastDisjointPair?.first ?: "No Hour set"}, Minute set: ${leastDisjointPair?.second ?: "No Minute set"}")
        println("===== End of least disjoint pair ====")

        val bestHourList = leastDisjointPair?.first ?: emptyList()
        println("===== Printing smallest size hourlist ====")
        println(bestHourList)
        val bestMinutesList = leastDisjointPair?.second ?: emptyList()
        println("===== Printing smallest size minuteslist ====")
        println(bestMinutesList)
        ConvertToColorCode(bestHourList, bestMinutesList)

    }
    else
    {

        println("**** RESULT **** Printing the best joint pair **** COLOR CODE ****")
        // Finding the smallest list in the hourList
        val smallestHourList = hourlist.minByOrNull { it.size }

        println("===== Printing smallest size hourlist ====")
        println(smallestHourList)
        // Finding the smallest list in the minutesList
        val smallestMinutesList = minuteslist.minByOrNull { it.size }
        println("===== Printing smallest size minuteslist ====")
        println(smallestMinutesList)
        ConvertToColorCode(smallestHourList, smallestMinutesList)
    }

    println("<---- printing time in work")
    println(colorViewModel.hours.value)
    println(colorViewModel.minutes.value)
    println(colorViewModel.dayNightState.value)
    println("<---- End printing time ")
}


