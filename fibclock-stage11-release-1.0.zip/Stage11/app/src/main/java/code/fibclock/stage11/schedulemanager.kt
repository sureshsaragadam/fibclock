package code.fibclock.stage11

import ColorViewModel
import android.os.Handler
import android.os.Looper
import java.util.Calendar

class SchedulingManager(private val viewModel: ColorViewModel) {

    private val handler = Handler(Looper.getMainLooper())
    private val intervalMillis: Long = 5 * 60 * 1000 // 5 minutes in milliseconds

    private val runnable = object : Runnable {
        override fun run() {
            // Call the function to update time
            getmyTime(viewModel)

            // Schedule the next execution
            handler.postDelayed(this, intervalMillis)
        }
    }

    // Function to calculate delay for the first execution
    private fun calculateInitialDelay(): Long {
        val now = Calendar.getInstance()
        val minutes = now.get(Calendar.MINUTE)
        val seconds = now.get(Calendar.SECOND)
        val milliseconds = now.get(Calendar.MILLISECOND)

        // Calculate the next 5-minute interval
        val next5MinMark = ((minutes / 5) + 1) * 5
        val delayMinutes = next5MinMark - minutes
        return (delayMinutes * 60 * 1000 - (seconds * 1000 + milliseconds)).toLong()
    }

    // Method to start scheduling
    fun startScheduling() {
        // Perform the initial call without delay
        getmyTime(viewModel)

        // Calculate delay for the first scheduled call
        val initialDelay = calculateInitialDelay()

        // Schedule the first execution
        handler.postDelayed(runnable, initialDelay)
    }

    // Method to stop scheduling
    fun stopScheduling() {
        handler.removeCallbacks(runnable)
    }
}
