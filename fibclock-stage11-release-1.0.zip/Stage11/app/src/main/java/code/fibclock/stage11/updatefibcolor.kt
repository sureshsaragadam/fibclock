package code.fibclock.stage11
import ColorViewModel
import android.annotation.SuppressLint
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun UpdateNewColors(newColorsList: List<Color>) {
    // Use LaunchedEffect to run coroutine once
    val ViewModel: ColorViewModel = viewModel()
    val coroutineScope = rememberCoroutineScope()
        coroutineScope.launch {
            ViewModel.updateColors(newColorsList)
        }
    }
