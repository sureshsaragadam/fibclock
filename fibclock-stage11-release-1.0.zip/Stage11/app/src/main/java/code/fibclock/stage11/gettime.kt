package code.fibclock.stage11
import ColorViewModel
import DayNightState
import java.text.SimpleDateFormat
import java.util.Date


fun getmyTime(viewModel: ColorViewModel) {
    val currentTime = Date()
    val formatter = SimpleDateFormat("hh:mm a") // Use "hh" for 12-hour format
    val formattedTime = formatter.format(currentTime)

    val hours = formattedTime.substringBefore(":")
    val minutes = formattedTime.substringAfter(":").substringBefore(" ")
    val amPm = formattedTime.substringAfterLast(" ")

    println("Current time: $formattedTime")
    println("Hours: $hours")
    println("Minutes: $minutes")
    println("AM/PM: $amPm")

    val hoursInt = hours.toInt()
    val minutesInt = minutes.toInt()

    val roundOffMinutes = minutesInt / 5 * 5
//    val isDayTime = amPm == "AM"

    // Update the ViewModel states
    viewModel.updateTime(hoursInt, roundOffMinutes)
    if (amPm == "AM")
    viewModel.setDayNightState(DayNightState.AM)
    else if(amPm == "PM")
    viewModel.setDayNightState(DayNightState.PM)
}
