package code.fibclock.stage11
import ColorViewModel
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun FibonacciRowColumnLayout(widthDp: Dp, heightDp: Dp, cellSizeDp: Dp, dynamicFontSize: TextUnit) {

    val colorViewModel : ColorViewModel = viewModel()
    val colorsState by colorViewModel.colorsVMState
    val setDayNight by colorViewModel.dayNightState
//    val dayNightState by viewModel().dayNightState.observeAsState(DayNightState.DAY)

    /*
    val coroutineScope = rememberCoroutineScope()
    coroutineScope.launch {
        colorViewModel.updateColors(listOf(Color.Gray, Color.Gray, Color.Gray, Color.Gray, Color.Gray))
    }
 */

    Row( // main row
        modifier = Modifier
            .fillMaxSize()
            .border(2.dp, Color.Black)
            .background(color = Color.Black),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column( // left column
            modifier = Modifier
                .border(2.dp, Color.Black)
                .height(heightDp)
                .width(cellSizeDp * 3),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        )
        {
            Row( // left coloum up scope

                modifier = Modifier
                    //  .weight(0f)
                    .border(2.dp, Color.Black)
                    .height(cellSizeDp * 2)
                    .width(cellSizeDp * 3),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    // left column // BLOCK 3
                    modifier = Modifier
                        .border(2.dp, Color.Black)
                        .height(cellSizeDp * 2)
                        .width(cellSizeDp * 2)
                        .background(colorsState[2]),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Text(
                        text = "2", style = TextStyle(
                            fontSize = dynamicFontSize,
                            color = Color.Black,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Column(
                    // left column
                    modifier = Modifier
                        .border(2.dp, Color.Black)
                        .height(cellSizeDp * 2)
                        .width(cellSizeDp * 2)
                        .background(colorsState[2]),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                )
                {
                    Row(
                        // Block 1

                        modifier = Modifier
                            .border(2.dp, Color.Black)
                            .height(cellSizeDp)
                            .width(cellSizeDp)
                            .background(colorsState[1]),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Text(
                            text = "1", style = TextStyle(
                                fontSize = dynamicFontSize,
                                color = Color.Black,
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Bold
                            ), modifier = Modifier.padding(10.dp)
                        )
                    }

                    Row(
                        // BLOCK 2
                        modifier = Modifier
                            .border(2.dp, Color.Black)
                            .height(cellSizeDp)
                            .width(cellSizeDp)
                            .background(colorsState[0]),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Text(
                            text = "1", style = TextStyle(
                                fontSize = dynamicFontSize,
                                color = Color.Black,
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Bold
                            ), modifier = Modifier.padding(10.dp)
                        )
                    }
                }

            }
            Row( // left column down scope SCOPE // BLOCK 4
                modifier = Modifier
                    //  .weight(0f)
                    .border(2.dp, Color.Black)
                    .height(cellSizeDp * 3)
                    .width(cellSizeDp * 3)
                    .background(colorsState[3]),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Text(
                    text = "3", style = TextStyle(
                        fontSize = dynamicFontSize,
                        color = Color.Black,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold
                    ), modifier = Modifier.padding(10.dp)
                )
            } // Row Down Scope BLOCK 4
        }// Column Left Scope

        Column( // Right column SCOPE 5 // BLOCK 5
            modifier = Modifier
                .border(2.dp, Color.Black)
                .height(heightDp)
                .width(cellSizeDp * 5)
                //   .border(2.dp, Color.Black)
                .background(colorsState[4])
                .testTag("tag1"),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Box(
                modifier = Modifier.fillMaxSize(),
            ) {
                Text(
                    text = setDayNight.period,
                    style = TextStyle(
                        fontSize = dynamicFontSize/2,
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                    ),
                    modifier = Modifier
                        .padding(top = 12.dp, end = 28.dp)
                        .align(Alignment.TopEnd) // Align this Text in the center
                )

                // Top-right Text
                Text(
                    text = "5",
                    style = TextStyle(
                        fontSize = dynamicFontSize,
                        color = Color.Black,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold,
                    ),
                    modifier = Modifier.align(Alignment.Center)// Align this Text at the top-right
                )
            }



            /*
            Box(modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.TopEnd,
                )
            {
                Text(
                    text = "5", style = TextStyle(
                        fontSize = dynamicFontSize,
                        color = Color.Black,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold,
                    )
                )
                Text(
                    text = "\u263C", style = TextStyle(
                        fontSize = dynamicFontSize,
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                    )
                )
            }

 */
        } // Column Right Scope BLOCK 5
    } // Main Ro
    /*
    // Trigger the color change after 5 seconds
    LaunchedEffect(Unit) {
        scope.launch {
            delay(5000)
            colorsState = newColors

            delay(5000)
            colorsState = listOf(Color.Green, Color.White, Color.White, Color.Green, Color.Blue)
            delay(5000)
            colorsState = listOf(Color.White, Color.White, Color.Red, Color.White, Color.Red)
        }
    }

     */
}// fun FibonacciRowColumnLayout


