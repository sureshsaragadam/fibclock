package code.fibclock.stage11

import ColorViewModel
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider

class MainActivity : ComponentActivity() {
    private lateinit var colorViewModel: ColorViewModel
    private lateinit var schedulingManager: SchedulingManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Initialize ViewModel
            colorViewModel = ViewModelProvider(this).get(ColorViewModel::class.java)
            // Initialize SchedulingManager with ViewModel
            schedulingManager = SchedulingManager(colorViewModel)
            // Start scheduling
            schedulingManager.startScheduling()
            GridSettoDp()
            HandlePowerSet(colorViewModel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Stop scheduling when the activity is destroyed
        schedulingManager.stopScheduling()
    }

}


@Composable
fun GridSettoDp() {
    val configuration = LocalConfiguration.current
    val heightDp = configuration.screenHeightDp.dp

    val cellSizeDp = heightDp / 5
    val widthDp = cellSizeDp * 8

    val dynamicFontSize = (cellSizeDp/2) .value.sp

    FibonacciRowColumnLayout(widthDp, heightDp, cellSizeDp, dynamicFontSize)
}
