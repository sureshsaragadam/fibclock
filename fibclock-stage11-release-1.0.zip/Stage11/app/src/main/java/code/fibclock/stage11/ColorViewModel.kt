import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
// Enum class declaration within the same file
/*
enum class DayNightState(val unicode: String) {
    DAY("\u263C"),   // Unicode for day symbol
    NIGHT("\u263E")  // Unicode for night symbol
}

 */
enum class DayNightState(val period: String) {
    AM("AM"),  // Represents the AM period
    PM("PM")   // Represents the PM period
}
class ColorViewModel: ViewModel() {


    // Private mutable state
    private val _colorsVMState = mutableStateOf(listOf(Color.Gray, Color.Gray, Color.Gray, Color.Gray, Color.Gray))

    // Public read-only state
    val colorsVMState: State<List<Color>> get() = _colorsVMState

    // Private mutable states for hours, minutes, and isDayTime
    private val _hours = mutableStateOf(0)
    private val _minutes = mutableStateOf(0)
    private val _dayNightState = mutableStateOf(DayNightState.AM)

    // Public read-only states for hours, minutes, and isDayTime
    val hours: State<Int> get() = _hours
    val minutes: State<Int> get() = _minutes
    val dayNightState: State<DayNightState> get() = _dayNightState
    // Method to update colors
    fun updateColors(newColors: List<Color>) {
        _colorsVMState.value = newColors
    }

    // Method to update time (hours and minutes)
    fun updateTime(newHours: Int, newMinutes: Int) {
        _hours.value = newHours
        _minutes.value = newMinutes
    }
    // Method to update day/night state
    fun setDayNightState(state: DayNightState) {
        _dayNightState.value = state
    //    if (_dayNightState.value != state) {
    //        _dayNightState.value = state
    //    }
    }

}
