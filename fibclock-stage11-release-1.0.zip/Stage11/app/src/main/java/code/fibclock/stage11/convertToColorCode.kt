package code.fibclock.stage11

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun ConvertToColorCode(hourList: List<Int>?, minuteList: List<Int>?) {
    val safeHourList = hourList ?: emptyList()
    val safeMinutesList = minuteList ?: emptyList()
    var newColor = mutableListOf(Color.White, Color.White, Color.White, Color.White, Color.White)

    println("!!!!!!!!!!!!!! READY TO CONVERT TO COLOR CODE !!!!!!!!!!!!!!!")
    println("Hour List: $safeHourList  Minute List: $safeMinutesList")
    // Add your logic to convert these lists to color codes

    safeHourList.forEach { listvalue ->
        when (listvalue) {
            0 -> {
                println("Set Block 0 to RED")
                newColor[0] = Color.Red
            }
            1 -> {
                println("Set Block 1 to RED")
                newColor[1] = Color.Red
            }
            2 -> {
                println("Set Block 2 to RED")
                newColor[2] = Color.Red
            }
            3 -> {
                println("Set Block 3 to RED")
                newColor[3] = Color.Red
            }
            5 -> {
                println("Set Block 5 to RED")
                newColor[4] = Color.Red
            }
            else -> {
                println("Other value: $listvalue")
            }
        }
    }

    safeMinutesList.forEach { listvalue ->
        when (listvalue) {
            0 -> {
                println("Set Block 0 to GREEN")
                newColor[0] = Color.Green
            }
            1 -> {
                println("Set Block 1 to GREEN")
                newColor[1] = Color.Green
            }
            2 -> {
                println("Set Block 2 to GREEN")
                newColor[2] = Color.Green
            }
            3 -> {
                println("Set Block 3 to GREEN")
                newColor[3] = Color.Green
            }
            5 -> {
                println("Set Block 5 to GREEN")
                newColor[4] = Color.Green
            }
            else -> {
                println("Other value: $listvalue")
            }
        }
    }

    // Convert lists to sets
    val hourSet = safeHourList.toSet()
    val minutesSet = safeMinutesList.toSet()

    // Find intersection (common elements)
    val blueElements = hourSet.intersect(minutesSet)

    // Print common elements
    println("Common elements: $blueElements")

    blueElements.forEach { listvalue ->
        when (listvalue) {
            0 -> {
                println("Set Block 0 to BLUE")
                newColor[0] = Color.Blue
            }
            1 -> {
                println("Set Block 1 to BLUE")
                newColor[1] = Color.Blue
            }
            2 -> {
                println("Set Block 2 to BLUE")
                newColor[2] = Color.Blue
            }
            3 -> {
                println("Set Block 3 to BLUE")
                newColor[3] = Color.Blue
            }
            5 -> {
                println("Set Block 5 to BLUE")
                newColor[4] = Color.Blue
            }
            else -> {
                println("Other value: $listvalue")
            }
        }
    }
// newViewModel.setColor(newColor)
// print new color code
    println(newColor)
    UpdateNewColors(newColor)
}